ACTIVAR LOS SERVIDORES EN GENERAL

: en terminal -> php artisan serv
: en terminal -> npm run dev (si no ejecuta: npm install, antes)

FRONTEND
: Jetstream
: Livewire
: Tailwind CSS

PAQUETES INSTALADOS
: Jetstream
: Livewire
: spatie v6


MIGRACIONES
: EstadoProducto
: UnidadProducto
: Producto
: UsuarioProducto
: EstadoUsuario



BD
: PQSQL
: cambia las credenciales respecto a tu BD de tu pc
