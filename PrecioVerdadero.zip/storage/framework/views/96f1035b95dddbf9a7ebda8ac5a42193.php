<?php if (isset($component)) { $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54 = $attributes; } ?>
<?php $component = App\View\Components\AppLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\AppLayout::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
     <?php $__env->slot('header', null, []); ?> 
        <h2 class="font-semibold text-xl text-gray-800 leading-tight">
            <?php echo e(__('Gráficas de Precios - Mercader')); ?>

        </h2>
     <?php $__env->endSlot(); ?>

    <div class="py-6">
        <div class="max-w-7xl mx-auto sm:px-6 lg:px-8 space-y-8">
            <!-- Caja de Selección de Producto -->
            <div class="bg-white shadow rounded-lg overflow-hidden">
                <div class="bg-blue-500 px-6 py-4 text-white font-bold text-lg">
                    Selección de Producto
                </div>
                <div class="p-6">
                    <div class="mb-4">
                        <select id="productoSelect"
                            class="w-full border border-gray-300 rounded px-4 py-2 focus:outline-none focus:ring-2 focus:ring-blue-500"
                            onchange="actualizarGrafica()">
                            <option value="">-- Selecciona un producto --</option>
                            <?php $__currentLoopData = $productos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $producto): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($producto->id); ?>"><?php echo e($producto->nombre); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                    </div>
                </div>
            </div>

            <!-- Caja de Gráfica -->
            <div class="bg-white shadow rounded-lg overflow-hidden">
                <div class="bg-green-500 px-6 py-4 text-white font-bold text-lg">
                    Historial de Precios
                </div>
                <div class="p-6">
                    <canvas id="precioChart" class="w-full h-96"></canvas>
                </div>
            </div>
        </div>
    </div>

    <!-- Chart.js CDN -->
<script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
<script>
    let precioChart;

    function inicializarGrafica(labels = [], precios = []) {
        const ctx = document.getElementById('precioChart').getContext('2d');

        // Destroy existing chart if it exists
        if (precioChart) {
            precioChart.destroy();
        }

        precioChart = new Chart(ctx, {
            type: 'line', // Changed from 'bar' to 'line'
            data: {
                labels: labels,
                datasets: [{
                    label: 'Precio a través del tiempo',
                    data: precios,
                    backgroundColor: 'rgba(75, 192, 192, 0.2)', // Slightly transparent fill for the line
                    borderColor: 'rgba(75, 192, 192, 1)', // Solid line color
                    borderWidth: 2, // Thicker line for visibility
                    fill: true, // Fills the area under the line
                    tension: 0.4, // Adds smoothness to the line (adjust between 0 and 1)
                    pointBackgroundColor: 'rgba(75, 192, 192, 1)', // Color for data points
                    pointRadius: 4, // Size of data points
                    pointHoverRadius: 6 // Larger points on hover
                }]
            },
            options: {
                responsive: true,
                maintainAspectRatio: false,
                scales: {
                    y: {
                        beginAtZero: true,
                        title: {
                            display: true,
                            text: 'Precio'
                        }
                    },
                    x: {
                        title: {
                            display: true,
                            text: 'Fecha y Hora'
                        }
                    }
                }
            }
        });
    }

    function actualizarGrafica() {
        const productoId = document.getElementById('productoSelect').value;

        if (!productoId) {
            inicializarGrafica(); // Initialize empty chart
            return;
        }

        // Fetch price history via AJAX
        fetch(`/graficas/precios/${productoId}`)
            .then(response => response.json())
            .then(data => {
                inicializarGrafica(data.labels, data.precios);
            })
            .catch(error => {
                console.error('Error fetching price history:', error);
                inicializarGrafica(); // Initialize empty chart on error
            });
    }

    // Initialize empty chart on page load
    document.addEventListener('DOMContentLoaded', () => {
        inicializarGrafica();
    });
</script>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $attributes = $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $component = $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?><?php /**PATH C:\PROYECTOSW\PrecioVerdadero\resources\views/graficas/index.blade.php ENDPATH**/ ?>