<?php if (isset($component)) { $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54 = $attributes; } ?>
<?php $component = App\View\Components\AppLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\AppLayout::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
     <?php $__env->slot('header', null, []); ?> 
        <h2 class="font-semibold text-xl text-gray-800 leading-tight">
            <?php echo e(__('Mis Tiendas')); ?>

        </h2>
     <?php $__env->endSlot(); ?>

    <div class="py-12">
        <div class="max-w-7xl mx-auto sm:px-6 lg:px-8">
            <div class="bg-white overflow-hidden shadow-xl sm:rounded-lg p-6">
                <?php if(session('success')): ?>
                    <div class="mb-4 text-green-600 font-semibold">
                        <?php echo e(session('success')); ?>

                    </div>
                <?php endif; ?>

                <!-- Formulario para crear actividad -->
                <div class="mb-6">
                    <h3 class="text-lg font-semibold mb-4">Crear Actividad</h3>
                    <form id="form-actividad" method="POST" action="<?php echo e(route('actividad.store')); ?>">
                        <?php echo csrf_field(); ?>
                        <div class="mb-4">
                            <label class="block text-gray-700">Mercader:</label>
                            <select name="id_usuario_mercader" class="w-full border border-gray-300 rounded px-3 py-2" required>
                                <?php $__currentLoopData = \App\Models\User::role('mercader')->get(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $mercader): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($mercader->id); ?>"><?php echo e($mercader->name); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                        </div>
                        <div class="mb-4">
                            <label class="block text-gray-700">Cliente:</label>
                            <select name="id_usuario_cliente" class="w-full border border-gray-300 rounded px-3 py-2" required>
                                <?php $__currentLoopData = \App\Models\User::role('cliente')->get(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cliente): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($cliente->id); ?>"><?php echo e($cliente->name); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                        </div>
                        <div class="mb-4">
                            <label class="block text-gray-700">Tipo de Actividad:</label>
                            <select name="id_tipo_actividad" class="w-full border border-gray-300 rounded px-3 py-2" required>
                                <?php $__currentLoopData = \App\Models\TipoActividad::all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tipo): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($tipo->id); ?>"><?php echo e($tipo->nombre); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                        </div>
                        <button type="submit" class="bg-indigo-600 hover:bg-indigo-700 text-white px-4 py-2 rounded">Crear Actividad</button>
                    </form>
                    <div id="form-success" class="hidden mt-4 text-green-600 font-semibold"></div>
                </div>

                <?php if($tiendas->isEmpty()): ?>
                    <p>No tienes tiendas registradas.</p>
                <?php else: ?>
                    <table class="min-w-full divide-y divide-gray-200">
                        <thead class="bg-gray-100">
                            <tr>
                                <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Nombre</th>
                                <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Tipo</th>
                                <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Ubicación</th>
                                <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Acciones</th>
                            </tr>
                        </thead>
                        <tbody class="bg-white divide-y divide-gray-200">
                            <?php $__currentLoopData = $tiendas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tienda): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td class="px-6 py-4 whitespace-nowrap"><?php echo e($tienda->nombre); ?></td>
                                    <td class="px-6 py-4 whitespace-nowrap"><?php echo e($tienda->tipo); ?></td>
                                    <td class="px-6 py-4 whitespace-nowrap">
                                        <?php if($tienda->ubicacion): ?>
                                            <?php echo e($tienda->ubicacion->direccion); ?>

                                        <?php else: ?>
                                            Sin ubicación
                                        <?php endif; ?>
                                    </td>
                                    <td class="px-6 py-4 whitespace-nowrap">
                                        <button onclick="openEditModal(<?php echo e($tienda->id); ?>, '<?php echo e($tienda->nombre); ?>', '<?php echo e($tienda->tipo); ?>')"
                                                class="bg-yellow-400 hover:bg-yellow-500 text-white px-3 py-1 rounded">
                                            Editar
                                        </button>
                                        <button onclick="openUbicacionModal(<?php echo e($tienda->id); ?>, <?php echo e($tienda->ubicacion ? $tienda->ubicacion->id : 'null'); ?>, <?php echo e($tienda->ubicacion ? $tienda->ubicacion->latitud : 'null'); ?>, <?php echo e($tienda->ubicacion ? $tienda->ubicacion->longitud : 'null'); ?>, '<?php echo e($tienda->ubicacion ? $tienda->ubicacion->direccion : ''); ?>')"
                                                class="bg-blue-400 hover:bg-blue-500 text-white px-3 py-1 rounded">
                                            <?php echo e($tienda->ubicacion ? 'Editar Ubicación' : 'Agregar Ubicación'); ?>

                                        </button>
                                        <form action="<?php echo e(route('tienda.destroy', $tienda->id)); ?>" method="POST" class="inline">
                                            <?php echo csrf_field(); ?>
                                            <?php echo method_field('DELETE'); ?>
                                            <button type="submit" onclick="return confirm('¿Estás seguro?')" class="text-red-500 hover:text-red-700">Eliminar</button>
                                        </form>
                                    </td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                <?php endif; ?>

                <button onclick="openCreateModal()" class="mt-6 bg-indigo-500 hover:bg-indigo-600 text-white px-4 py-2 rounded">Crear Tienda</button>
            </div>
        </div>
    </div>

    <?php echo $__env->make('tienda.modal', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <script src="<?php echo e(asset('js/app.js')); ?>"></script>
    <script>
        $('#form-actividad').on('submit', function (e) {
            e.preventDefault();
            $.ajax({
                url: this.action,
                type: 'POST',
                data: $(this).serialize(),
                success: function (response) {
                    $('#form-success').text(response.message).removeClass('hidden');
                    $('#form-actividad').trigger('reset');
                    setTimeout(() => $('#form-success').addClass('hidden'), 5000);
                },
                error: function (xhr) {
                    alert('Error al crear la actividad: ' + xhr.responseJSON.message);
                }
            });
        });
    </script>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $attributes = $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $component = $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?><?php /**PATH C:\PROYECTOSW\PrecioVerdadero\resources\views/tienda/index.blade.php ENDPATH**/ ?>