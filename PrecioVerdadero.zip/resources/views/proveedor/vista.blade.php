<!DOCTYPE html>
<html>
<head>
    <title>Vista Proveedor</title>
</head>
<body>
    <h1>Vista Proveedor</h1>
</body>
</html>